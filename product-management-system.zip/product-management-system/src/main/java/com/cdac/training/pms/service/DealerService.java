package com.cdac.training.pms.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.training.pms.model.Dealer;
import com.cdac.training.pms.repository.DealerRepository;

@Service
public class DealerService {
	
	@Autowired
	private DealerRepository drepo;
	
	public void saveDealer(Dealer dealer) {
        drepo.save(dealer);  // invokes save() method of JPA repo
    }
	
	public Dealer findByEmail(String email)
	{
	 	        return drepo.findByEmail(email); //invoke custom method (non-id field)
	    }

}
