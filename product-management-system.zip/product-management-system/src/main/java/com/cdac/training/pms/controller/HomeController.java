package com.cdac.training.pms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	
	/* To Create JSp file
	 * From Eclipse Market place -- Search JSp & Install 
	 * "Eclispe Enterprise & WebDeveloper Tools" 
	 */
	//http://localhost:8083/productapp/ - REST endpoint
	@GetMapping("/")
	public String viewHomePage() {
        
	    return "index";
	}

}
