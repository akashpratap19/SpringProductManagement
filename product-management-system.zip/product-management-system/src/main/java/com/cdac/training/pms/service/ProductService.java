package com.cdac.training.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.training.pms.model.Product;
import com.cdac.training.pms.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired //DI using fields
	private ProductRepository prepo;
	
	//Save & Update 
	public void saveProduct(Product product) { // saveProduct is user-defined method in service class
        prepo.save(product); // save method pre-defined in JPA repo
    }
	
	public List<Product> listAll() {
        return prepo.findAll(); // pre-defined in JPA repo
    }
	
	//Used to Update
	 	public Product getSingleProduct(long id) {
	        return prepo.findById(id).get();  // pre-defined  in JPA repo
	    }
	     
	    public void deleteProduct(long id) {
	        prepo.deleteById(id);  // pre-defined in JPA repo
	    }

}
