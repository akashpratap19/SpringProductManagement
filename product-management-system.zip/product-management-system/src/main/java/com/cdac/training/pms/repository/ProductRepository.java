package com.cdac.training.pms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.training.pms.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{
	
	//JPA repository consists of pre-defined methods for DB Operations
	// Call these methods from Service Layer using ProductRepository object
}
