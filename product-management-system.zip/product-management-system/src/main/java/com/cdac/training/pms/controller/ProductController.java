package com.cdac.training.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cdac.training.pms.model.Product;
import com.cdac.training.pms.service.ProductService;

// Controller layer interacts with service layer
@Controller
public class ProductController {
	
	@Autowired
	private ProductService pservice;
	
	@GetMapping("/newproduct")
	public String showNewProductPage(Model model) {
	    Product product = new Product();
	    model.addAttribute("product", product);
	     
	    return "new_product"; //return jsp + Product object
	}
	
	@PostMapping("/save")
	public String saveProduct(@ModelAttribute("product") Product product) {
	    pservice.saveProduct(product);
	   
	    return "redirect:products"; //redirects to @GetMapping("/products")
	}
	
	@GetMapping("/products")
	public String listProduct(Model model) {
	    List<Product> listProducts = pservice.listAll();
	    model.addAttribute("listProducts", listProducts);
	     
	    return "products"; // return jsp + listProducts ArrayList
	}
	
	@GetMapping("/editProduct")
	public ModelAndView showEditProductPage(@RequestParam("id") int id) {
	    ModelAndView mav = new ModelAndView("edit_product");
	    Product product = pservice.getSingleProduct(id);
	    mav.addObject("product", product);
	    return mav; ///returns edit_product.jsp + product Object
	}
	
	
	@GetMapping("/delete")
	public String deleteProduct(@RequestParam("id") int id) {
	    pservice.deleteProduct(id);
	    return "redirect:products";       //redirects to @GetMapping("/products")
	}

}
