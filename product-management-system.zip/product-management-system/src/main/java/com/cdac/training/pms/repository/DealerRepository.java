package com.cdac.training.pms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.training.pms.model.Dealer;

public interface DealerRepository extends JpaRepository<Dealer, Long> {
	
	//Custom Methods
	// Fetch record/object based on email - non Id field
		public Dealer findByEmail(String email);

}
